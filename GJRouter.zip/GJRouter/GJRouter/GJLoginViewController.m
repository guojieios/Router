//
//  GJLoginViewController.m
//  GJRouter
//
//  Created by guojie on 2018/11/27.
//  Copyright © 2018 guojie. All rights reserved.
//

#import "GJLoginViewController.h"

@interface GJLoginViewController ()


@property(nonatomic, strong) NSString *className;

@end

@implementation GJLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.className = self.name;
    
    NSLog(@"名字应该是 ：%@",self.name);
    
    if (self.callBack) {
        self.callBack(self.className);
    }
    
    
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
