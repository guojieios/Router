//
//  GJLoginViewController.h
//  GJRouter
//
//  Created by guojie on 2018/11/27.
//  Copyright © 2018 guojie. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface GJLoginViewController : UIViewController

@property(nonatomic, copy) NSString *name;

@property(nonatomic, copy)void (^callBack)(NSString *str);

@end

NS_ASSUME_NONNULL_END
