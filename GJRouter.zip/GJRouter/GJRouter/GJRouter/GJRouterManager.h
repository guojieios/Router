//
//  GJRouterManager.h
//  GJRouter
//
//  Created by guojie on 2018/11/27.
//  Copyright © 2018 guojie. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "GJCurrentController.h"


NS_ASSUME_NONNULL_BEGIN


UIViewController  *_Nonnull gj_controller(NSString * _Nullable name);

@interface GJRouterManager : NSObject

//  单例创建
+ (instancetype)shareInstanceRouter;



//  类名 传入  设置 跳转
- (BOOL)pushVcNameStr:(NSString *)vcStr from:(UIViewController *)fromvc withData:(NSDictionary *__nullable)data;

- (BOOL)presentVcNameStr:(NSString *)vcStr from:(UIViewController *)fromvc withData:(NSDictionary *__nullable)data;

@end

NS_ASSUME_NONNULL_END
