//
//  UIViewController+GJRoute.m
//  GJRouter
//
//  Created by guojie on 2018/11/27.
//  Copyright © 2018 guojie. All rights reserved.
//

#import "UIViewController+GJRoute.h"

@implementation UIViewController (GJRoute)


- (BOOL)gj_pushVcName:(NSString *)vcNameStr {
    
    return [[GJRouterManager shareInstanceRouter] pushVcNameStr:vcNameStr from:self withData:nil];
    
}

- (BOOL)gj_presentVcName:(NSString *)vcNameStr {
    
    return [[GJRouterManager shareInstanceRouter] presentVcNameStr:vcNameStr from:self withData:nil];
    
}

- (BOOL)gj_pushVcName:(NSString *)vcNameStr withData:(NSDictionary *)data {
    
    return [[GJRouterManager shareInstanceRouter] pushVcNameStr:vcNameStr from:self withData:data];
}

- (BOOL)gj_presentVcName:(NSString *)vcNameStr withData:(NSDictionary *)data {
    
    return [[GJRouterManager shareInstanceRouter] presentVcNameStr:vcNameStr from:self withData:data];
    
}


@end
