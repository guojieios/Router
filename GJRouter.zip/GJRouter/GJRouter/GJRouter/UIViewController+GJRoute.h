//
//  UIViewController+GJRoute.h
//  GJRouter
//
//  Created by guojie on 2018/11/27.
//  Copyright © 2018 guojie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GJRouterManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (GJRoute)


- (BOOL)gj_pushVcName:(NSString *)vcNameStr;

- (BOOL)gj_presentVcName:(NSString *)vcNameStr;

- (BOOL)gj_pushVcName:(NSString *)vcNameStr withData:(NSDictionary *)data;

- (BOOL)gj_presentVcName:(NSString *)vcNameStr withData:(NSDictionary *)data;


@end

NS_ASSUME_NONNULL_END
