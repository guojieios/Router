//
//  GJRouter.m
//  GJRouter
//
//  Created by guojie on 2018/11/27.
//  Copyright © 2018 guojie. All rights reserved.
//


#ifndef GJRouter_h
#define GJRouter_h

#import "GJRouterManager.h"
#import "UIViewController+GJRoute.h"
#import "GJCurrentController.h"

#endif /* GJRouter_h */



