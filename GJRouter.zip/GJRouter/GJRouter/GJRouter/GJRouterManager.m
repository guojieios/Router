//
//  GJRouterManager.m
//  GJRouter
//
//  Created by guojie on 2018/11/27.
//  Copyright © 2018 guojie. All rights reserved.
//

#import "GJRouterManager.h"

@implementation GJRouterManager




#pragma mark - 控制器函数
UIViewController * _Nonnull gj_controller(NSString *name){
    
    if (!name || name.length == 0) {
        NSLog(@"请传入class名");
        return nil;
    }

    id vc = [[NSClassFromString(name) alloc] init];
    if (vc) {
        if ([vc isKindOfClass:[UIViewController class]]) {
            return vc;
        }
        NSString *error = [NSString stringWithFormat:@"Class %@不是controller",name];
        NSLog(@"%@", error);
        return nil;
    }else{
        NSString *error = [NSString stringWithFormat:@"Class %@不存在",name];
        NSLog(@"%@", error);
        return nil;
    }
}


//  单例创建
+ (instancetype)shareInstanceRouter {
    static GJRouterManager *router = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        router = [[GJRouterManager alloc] init];
    });
    
    
    return router;
    
}





#pragma mark - 加入一层 校验 类名称
- (BOOL)pushVcNameStr:(NSString *)vcStr from:(UIViewController *)fromvc withData:(NSDictionary *)data {
    
//     对类名 称 校验
    UIViewController *vc = gj_controller(vcStr);
    
    return [self pushController:vc fromController:fromvc withData:data];
}

#pragma mark - 跳出
- (BOOL)presentVcNameStr:(NSString *)vcStr from:(UIViewController *)fromvc withData:(NSDictionary *)data {
    UIViewController *vc = gj_controller(vcStr);
    
    return [self presentController:vc fromController:fromvc withData:data];
}





#pragma mark - 跳转 方法
- (BOOL)presentController:(UIViewController *)vc fromController:(UIViewController *)fromVC  withData:(NSDictionary *)data {
    
    UIViewController *tempVC = fromVC ? fromVC : getCurrentController();
    if (!vc) {
        return NO;
    }
    [data enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        @try {
            
            [vc setValue:obj forKey:key];
            
        } @catch (NSException *exception) {
            
        } @finally {
            
        }
    }];
    
    
    [tempVC presentViewController:vc animated:YES completion:^{
        
    }];
    return YES;
    
    
}


#pragma mark - 跳转 方法
- (BOOL)pushController:(UIViewController *)vc fromController:(UIViewController *)fromVC  withData:(NSDictionary *)data {
    
    UIViewController *tempVC = fromVC ? fromVC : getCurrentController();
    if (!vc) {
        return NO;
    }
    [data enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        @try {
            
            [vc setValue:obj forKey:key];
            
        } @catch (NSException *exception) {
            
        } @finally {
            
        }
    }];
    vc.hidesBottomBarWhenPushed = YES;
    [tempVC.navigationController pushViewController:vc animated:YES];
    return YES;
}



UIViewController *_Nonnull getCurrentController() {
    
   return [GJCurrentController getCurrentControl];
    
    
}





@end
