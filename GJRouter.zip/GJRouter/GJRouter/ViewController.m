//
//  ViewController.m
//  GJRouter
//
//  Created by guojie on 2018/11/27.
//  Copyright © 2018 guojie. All rights reserved.
//

#import "ViewController.h"
#import "GJRouter.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)skipButtonclick:(id)sender {
    
    id block = ^(NSString *str){
        NSLog(@"传递的是这个block ： %@",str);
    };
    
    
    [self gj_pushVcName:@"GJLoginViewController" withData:@{
                                       @"name":@"GJLoginViewController",
                                       @"callBack":block
                                       }];
    
    
    
}

@end
